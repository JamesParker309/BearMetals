document.getElementById('yr').textContent = new Date().getFullYear();

const form = document.getElementById('inquireForm');
const msg = document.getElementById('formMsg');
const kind = form.getAttribute('data-kind') || 'inquiry';

/* ---------- Validators ---------- */

function setError(el, message) {
  if (!el) return;
  const field = el.closest('.field');
  if (!field) return;
  let err = field.querySelector('.field-error');
  if (!err) {
    err = document.createElement('span');
    err.className = 'field-error';
    field.appendChild(err);
  }
  if (message) {
    err.textContent = message;
    field.classList.add('has-error');
    el.setAttribute('aria-invalid', 'true');
  } else {
    err.textContent = '';
    field.classList.remove('has-error');
    el.removeAttribute('aria-invalid');
  }
}

function validateEmail(value) {
  const v = String(value || '').trim();
  if (!v) return 'Email is required.';
  // Standard email: local@domain.tld — must contain @ and a dot in the domain.
  const re = /^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$/;
  if (!re.test(v)) return 'Enter a valid email address (e.g. you@firm.com).';
  return null;
}

function validatePhone(value, required) {
  const v = String(value || '').trim();
  if (!v) return required ? 'WhatsApp number is required.' : null;
  // Strip common formatting characters
  const cleaned = v.replace(/[\s\-().]/g, '');
  // E.164-style: optional +, 7-15 digits total
  if (!/^\+?\d{7,15}$/.test(cleaned)) {
    return 'Enter a valid number with country code (e.g. +254 712 345 678).';
  }
  return null;
}

function validateText(value, label) {
  if (!String(value || '').trim()) return (label || 'This field') + ' is required.';
  return null;
}

/* ---------- "Other" specify fields ---------- */

// Wire any <select data-specify="targetFieldId"> to show/hide and require the target
// when the user picks "Other".
const specifyControllers = form.querySelectorAll('[data-specify]');
specifyControllers.forEach(sel => {
  const targetId = sel.getAttribute('data-specify');
  const targetField = document.getElementById(targetId);
  if (!targetField) return;
  const targetInput = targetField.querySelector('input, textarea, select');

  function sync() {
    const picked = String(sel.value || '').trim().toLowerCase();
    const isOther = picked === 'other';
    targetField.hidden = !isOther;
    if (targetInput) {
      if (isOther) {
        targetInput.setAttribute('required', 'required');
      } else {
        targetInput.removeAttribute('required');
        targetInput.value = '';
        setError(targetInput, null);
      }
    }
  }
  sel.addEventListener('change', sync);
  sync();
});

/* ---------- Live re-validation as user fixes errors ---------- */

form.querySelectorAll('input, select, textarea').forEach(el => {
  el.addEventListener('input', () => {
    if (el.closest('.field')?.classList.contains('has-error')) {
      setError(el, null);
    }
  });
  el.addEventListener('change', () => {
    if (el.closest('.field')?.classList.contains('has-error')) {
      setError(el, null);
    }
  });
});

/* ---------- Submit ---------- */

form.addEventListener('submit', (ev) => {
  ev.preventDefault();
  msg.textContent = '';
  msg.style.color = 'var(--copper)';

  let firstInvalid = null;
  const fail = (el, message) => {
    setError(el, message);
    if (!firstInvalid) firstInvalid = el;
  };

  // Clear prior errors
  form.querySelectorAll('.has-error').forEach(f => {
    f.classList.remove('has-error');
    const e = f.querySelector('.field-error');
    if (e) e.textContent = '';
  });

  // Validate every required field generically
  form.querySelectorAll('[required]').forEach(el => {
    // Skip hidden "specify" fields whose parent is hidden
    const field = el.closest('.field');
    if (field && field.hidden) return;

    const type = (el.getAttribute('type') || el.tagName).toLowerCase();
    const labelText = (field?.querySelector('label')?.textContent || '').replace(/\*+\s*$/, '').trim();
    const label = labelText || 'This field';

    if (el.type === 'email') {
      const err = validateEmail(el.value);
      if (err) fail(el, err);
    } else if (el.type === 'tel') {
      const err = validatePhone(el.value, true);
      if (err) fail(el, err);
    } else if (el.tagName === 'SELECT') {
      if (!String(el.value || '').trim()) fail(el, 'Please choose an option.');
    } else {
      const err = validateText(el.value, label);
      if (err) fail(el, err);
    }
  });

  // Also validate optional email/tel fields if user typed something
  form.querySelectorAll('input[type="email"]:not([required])').forEach(el => {
    if (String(el.value || '').trim()) {
      const err = validateEmail(el.value);
      if (err) fail(el, err);
    }
  });
  form.querySelectorAll('input[type="tel"]:not([required])').forEach(el => {
    if (String(el.value || '').trim()) {
      const err = validatePhone(el.value, false);
      if (err) fail(el, err);
    }
  });

  if (firstInvalid) {
    msg.textContent = 'Please correct the highlighted fields.';
    msg.style.color = 'var(--bronze)';
    try { firstInvalid.focus({ preventScroll: false }); } catch (e) { firstInvalid.focus(); }
    return;
  }

  const data = new FormData(form);
  msg.textContent = 'Sending inquiry…';
  msg.style.color = 'var(--copper)';

  // Destination inbox — change this once if the address ever moves.
  const INBOX = 'info@bearmetals.co';
  const kindLabel = kind.charAt(0).toUpperCase() + kind.slice(1);
  const subject = kindLabel + ' inquiry — ' + (data.get('company') || data.get('name') || 'New lead');

  // FormSubmit.co relays the POST to INBOX. The first submission to a new
  // address triggers a one-time activation email — click the link in it and
  // every future submission lands in the inbox directly. No API key required.
  const payload = new FormData();
  for (const [k, v] of data.entries()) {
    // Skip file uploads from the email body — FormSubmit's free tier doesn't
    // forward attachments reliably; the rest of the inquiry still goes through.
    if (k === 'document' && v instanceof File && !v.name) continue;
    if (v instanceof File && v.size === 0) continue;
    payload.append(k, v);
  }
  payload.append('_subject', subject);
  payload.append('_template', 'table');
  payload.append('_captcha', 'false');
  payload.append('inquiry_kind', kindLabel);
  payload.append('submitted_at', new Date().toISOString());
  payload.append('source_page', location.pathname.split('/').pop() || 'form');

  const redirect = () => {
    const params = new URLSearchParams();
    params.set('kind', kind);
    if (data.get('name')) params.set('name', data.get('name'));
    if (data.get('email')) params.set('email', data.get('email'));
    window.location.href = 'book.html?' + params.toString();
  };

  fetch('https://formsubmit.co/ajax/' + encodeURIComponent(INBOX), {
    method: 'POST',
    body: payload,
    headers: { 'Accept': 'application/json' },
  })
    .then(r => r.ok ? r.json() : Promise.reject(r))
    .then(() => {
      msg.textContent = 'Thank you. Redirecting to booking…';
      msg.style.color = 'var(--copper)';
      setTimeout(redirect, 600);
    })
    .catch(() => {
      // Network or relay failure — still get the user to the booking page so
      // they can reach us, and surface a hint to email directly.
      msg.textContent = 'Submitted offline. Redirecting to booking — please also email ' + INBOX + ' if you do not hear back.';
      msg.style.color = 'var(--bronze)';
      setTimeout(redirect, 1400);
    });
});
